import React from "react";

const InstructorProfilePolicies = () => {
  return <div>InstructorProfilePolicies</div>;
};

export default InstructorProfilePolicies;
