import React from "react";
import Login from "../Login/Login";

const InstructorLogin = () => {
  return <Login instructor={true} />;
};

export default InstructorLogin;
