export interface FetchErrorType {
  success: boolean;
  message: string;
}
