export interface Car {
  _id: string;
  id?: string;
  name: string;
  image: string;
}
