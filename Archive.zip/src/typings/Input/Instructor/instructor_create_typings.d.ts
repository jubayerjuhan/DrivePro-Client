export interface InstructorHasGSTOption {
  label: string;
  value: string;
}
