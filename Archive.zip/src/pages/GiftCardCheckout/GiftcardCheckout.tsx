import React from "react";

const GiftcardCheckout = () => {
  return <div>GiftcardCheckout</div>;
};

export default GiftcardCheckout;
